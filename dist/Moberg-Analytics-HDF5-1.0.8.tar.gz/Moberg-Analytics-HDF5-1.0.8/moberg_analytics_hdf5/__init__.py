# __init__.py

# Version of the Moberg-Analytics-HDF5 package
__version__ = "1.0.8"