# Moberg Analytics HDF5 Functions

This package provides user-friendly functions for reading HDF5 file content into Python. 

## Installation

You can install the Moberg Analytics HDF5 package from [PyPI](insert_link_to_pypi):

    pip install moberg-analytics-hdf5
    
This package was created using Python version 3.9.0.

## How to use

Pass the path to the HDF5 file on your local filesystem...
